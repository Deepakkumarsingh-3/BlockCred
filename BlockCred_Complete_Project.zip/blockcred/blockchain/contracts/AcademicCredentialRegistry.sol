// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Demo registry: stores credential hashes, not personal data.
contract AcademicCredentialRegistry {
    address public owner;
    mapping(bytes32 => bool) public credentialExists;
    mapping(bytes32 => bool) public isRevoked;

    event CredentialIssued(bytes32 indexed credentialHash, address indexed issuer);
    event CredentialRevoked(bytes32 indexed credentialHash, address indexed issuer);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function issueCredential(bytes32 credentialHash) external onlyOwner {
        require(credentialHash != bytes32(0), "Empty hash");
        require(!credentialExists[credentialHash], "Credential already exists");
        credentialExists[credentialHash] = true;
        emit CredentialIssued(credentialHash, msg.sender);
    }

    function revokeCredential(bytes32 credentialHash) external onlyOwner {
        require(credentialExists[credentialHash], "Credential not found");
        require(!isRevoked[credentialHash], "Already revoked");
        isRevoked[credentialHash] = true;
        emit CredentialRevoked(credentialHash, msg.sender);
    }
}
