const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("AcademicCredentialRegistry", function () {
  async function deploy() {
    const [owner, other] = await ethers.getSigners();
    const Registry = await ethers.getContractFactory("AcademicCredentialRegistry");
    const registry = await Registry.deploy();
    await registry.waitForDeployment();
    return { registry, owner, other };
  }

  it("issues and checks a credential hash", async function () {
    const { registry } = await deploy();
    const hash = ethers.keccak256(ethers.toUtf8Bytes("demo-credential"));
    await registry.issueCredential(hash);
    expect(await registry.credentialExists(hash)).to.equal(true);
    expect(await registry.isRevoked(hash)).to.equal(false);
  });

  it("prevents duplicate issuance", async function () {
    const { registry } = await deploy();
    const hash = ethers.keccak256(ethers.toUtf8Bytes("demo-credential"));
    await registry.issueCredential(hash);
    await expect(registry.issueCredential(hash)).to.be.revertedWith("Credential already exists");
  });

  it("restricts issuance to owner and supports revocation", async function () {
    const { registry, other } = await deploy();
    const hash = ethers.keccak256(ethers.toUtf8Bytes("demo-credential"));
    await expect(registry.connect(other).issueCredential(hash)).to.be.revertedWith("Only owner");
    await registry.issueCredential(hash);
    await registry.revokeCredential(hash);
    expect(await registry.isRevoked(hash)).to.equal(true);
  });
});
