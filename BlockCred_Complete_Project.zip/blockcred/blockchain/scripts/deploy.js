const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  const Registry = await hre.ethers.getContractFactory("AcademicCredentialRegistry");
  const registry = await Registry.deploy();
  await registry.waitForDeployment();
  const address = await registry.getAddress();
  console.log(`AcademicCredentialRegistry deployed to: ${address}`);

  const artifact = await hre.artifacts.readArtifact("AcademicCredentialRegistry");
  const destination = path.join(__dirname, "..", "..", "backend", "contract_abi.json");
  fs.writeFileSync(destination, JSON.stringify({ abi: artifact.abi }, null, 2));
  console.log(`ABI written to: ${destination}`);
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
