# BlockCred — Presentation Notes

## Abstract
BlockCred is a prototype academic credential verification system. It stores credential metadata in a database and records a deterministic cryptographic fingerprint in an Ethereum-compatible blockchain registry. A verifier can use a credential ID or QR code to check whether the record matches the on-chain hash and whether it has been revoked.

## Problem statement
Paper-based and manually verified academic credentials can be slow to validate and may be altered or forged. A verifier needs a practical way to check whether a presented credential matches a previously issued record.

## Objectives
- Create an issuer workflow for digital academic credentials.
- Generate a deterministic SHA-256 fingerprint of canonical credential fields.
- Record the fingerprint on a local blockchain through a Solidity contract.
- Verify credential records against the database and blockchain.
- Demonstrate QR-based lookup and revocation status.

## Existing vs proposed system
Existing workflows may rely on email, phone calls, paper records, or institution-specific portals. The proposed prototype uses a shared tamper-evident hash registry to make post-issuance modification detectable. It does not replace institutional governance or accreditation checks.

## Architecture
React/Vite frontend → FastAPI REST API → SQLite for off-chain metadata and Hardhat/EVM for on-chain hashes. The backend canonicalizes the credential fields, hashes them, submits the hash to the contract, and checks both the database record and chain during verification.

## Database
`credentials` stores credential fields, hash, transaction hash, chain confirmation, and revocation status. `verification_events` stores status and time for verification attempts.

## Smart contract
`AcademicCredentialRegistry` records unique bytes32 hashes, allows only the deployer/owner to issue and revoke, and emits issuance/revocation events. It stores no student name or certificate contents.

## Technology justification
- React/Vite: fast interactive frontend.
- FastAPI: typed REST endpoints and interactive Swagger docs.
- SQLite: simple persistent local database.
- Solidity/Hardhat: repeatable local EVM smart-contract demo.
- SHA-256: deterministic data fingerprint.
- QR code: convenient link to public verification.

## Scope and limitations
This is a local educational prototype. Demo issuer authorization is not production authentication. It does not prove the issuing institution is legitimate or that the original award decision was correct. Real deployments need institutional onboarding, robust identity/access management, privacy/legal review, key management, audit logging, backups, monitoring, and security testing.

## Five-minute demo
1. (0:00–0:40) Explain the forgery and verification-delay problem.
2. (0:40–1:40) Issue a fictional credential.
3. (1:40–2:20) Show the transaction hash and explain the on-chain fingerprint.
4. (2:20–3:20) Open the verification page using the generated URL/QR.
5. (3:20–4:00) Search a random ID and show INVALID.
6. (4:00–4:40) Revoke a credential and verify again.
7. (4:40–5:00) Summarize benefits and limitations.

## Ten-slide outline
1. Title and team
2. Problem statement
3. Existing system and limitations
4. Proposed solution
5. Objectives and scope
6. System architecture
7. Technology stack
8. Workflow and smart contract
9. Live demo and results
10. Limitations, future work, conclusion

## Likely viva questions
**Why blockchain?** It provides a shared tamper-evident record of credential fingerprints.
**Why store hashes instead of certificates?** To minimize on-chain personal data and storage costs.
**What is SHA-256?** A cryptographic hash function that maps data to a fixed 256-bit digest.
**What happens if a certificate changes?** Recomputed hash differs from the anchored hash.
**Can blockchain prove a degree is genuine?** No. It can show that a record matches an anchor; issuer legitimacy and the original award decision still need trust/governance.
**Why SQLite?** It is simple, persistent, and suitable for a local prototype.
**What is a smart contract?** Program code deployed to a blockchain and executed according to network rules.
**Why QR codes?** They provide quick access to a credential verification URL.
**What is revocation?** A status change indicating a previously issued credential should no longer be treated as valid.
**Is the project production-ready?** No; it is a prototype and needs security, privacy, governance, and deployment hardening.

## Completion checklist
Mark each item complete only after testing it locally:
- [ ] Local Hardhat node starts
- [ ] Contract compiles and deploys
- [ ] Backend connects to deployed contract
- [ ] Credential issue transaction confirmed
- [ ] Credential persists in SQLite
- [ ] QR URL opens verification page
- [ ] Valid credential returns VERIFIED
- [ ] Unknown ID returns INVALID
- [ ] Revocation returns REVOKED
- [ ] Frontend production build succeeds
