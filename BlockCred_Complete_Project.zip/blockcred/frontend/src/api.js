const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000'
const TOKEN = import.meta.env.VITE_DEMO_ISSUER_TOKEN || 'change-this-demo-token'
export async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) }
  if (options.method === 'POST' && path.includes('/credentials')) headers['X-Demo-Issuer-Token'] = TOKEN
  const response = await fetch(`${API}${path}`, { ...options, headers })
  const data = response.headers.get('content-type')?.includes('application/json') ? await response.json() : await response.blob()
  if (!response.ok) throw new Error(data?.detail || 'Request failed')
  return data
}
export { API }
