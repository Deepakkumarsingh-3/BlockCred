import hashlib, json
from app.main import make_hash

def test_hash_is_deterministic():
    payload = {"credential_id": "BC-TEST", "student_name": "Demo Student", "issue_date": "2026-10-24"}
    assert make_hash(payload) == make_hash(payload)
    assert len(make_hash(payload)) == 64
