import json
from pathlib import Path
from web3 import Web3
from .config import RPC_URL, CONTRACT_ADDRESS, ISSUER_PRIVATE_KEY, CHAIN_ID

ABI_PATH = Path(__file__).resolve().parents[1] / "contract_abi.json"

class ChainUnavailable(Exception):
    pass

def get_contract():
    if not CONTRACT_ADDRESS or not ABI_PATH.exists():
        raise ChainUnavailable("Blockchain is not configured. Deploy the contract and set CONTRACT_ADDRESS.")
    w3 = Web3(Web3.HTTPProvider(RPC_URL, request_kwargs={"timeout": 4}))
    if not w3.is_connected():
        raise ChainUnavailable("Cannot connect to the local blockchain. Start `npx hardhat node`.")
    abi_json = json.loads(ABI_PATH.read_text(encoding="utf-8"))
    abi = abi_json["abi"] if isinstance(abi_json, dict) else abi_json
    return w3, w3.eth.contract(address=Web3.to_checksum_address(CONTRACT_ADDRESS), abi=abi)

def issue_hash(hash_hex: str) -> str:
    if not ISSUER_PRIVATE_KEY:
        raise ChainUnavailable("ISSUER_PRIVATE_KEY is not configured in backend/.env.")
    w3, contract = get_contract()
    account = w3.eth.account.from_key(ISSUER_PRIVATE_KEY)
    tx = contract.functions.issueCredential(bytes.fromhex(hash_hex.removeprefix("0x"))).build_transaction({
        "from": account.address,
        "nonce": w3.eth.get_transaction_count(account.address),
        "chainId": CHAIN_ID,
        "gas": 250000,
        "gasPrice": w3.eth.gas_price,
    })
    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=30)
    if receipt.status != 1:
        raise ChainUnavailable("Blockchain transaction failed.")
    return tx_hash.hex()

def revoke_hash(hash_hex: str) -> str:
    if not ISSUER_PRIVATE_KEY:
        raise ChainUnavailable("ISSUER_PRIVATE_KEY is not configured in backend/.env.")
    w3, contract = get_contract()
    account = w3.eth.account.from_key(ISSUER_PRIVATE_KEY)
    tx = contract.functions.revokeCredential(bytes.fromhex(hash_hex.removeprefix("0x"))).build_transaction({
        "from": account.address,
        "nonce": w3.eth.get_transaction_count(account.address),
        "chainId": CHAIN_ID,
        "gas": 250000,
        "gasPrice": w3.eth.gas_price,
    })
    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=30)
    if receipt.status != 1:
        raise ChainUnavailable("Blockchain revocation transaction failed.")
    return tx_hash.hex()

def check_hash(hash_hex: str) -> tuple[bool, bool]:
    w3, contract = get_contract()
    value = bytes.fromhex(hash_hex.removeprefix("0x"))
    exists = contract.functions.credentialExists(value).call()
    revoked = contract.functions.isRevoked(value).call() if exists else False
    return exists, revoked
