import hashlib, json, uuid, io
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import desc
import qrcode
from .database import Base, engine, get_db
from .models import Credential, VerificationEvent
from .schemas import CredentialCreate
from .config import FRONTEND_URL, DEMO_ISSUER_TOKEN
from . import chain

Base.metadata.create_all(bind=engine)
app = FastAPI(title="BlockCred API", version="0.1.0", description="Academic credential verification prototype")
app.add_middleware(CORSMiddleware, allow_origins=[FRONTEND_URL, "http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def canonical_payload(data: dict) -> bytes:
    # Stable JSON serialization: sorted keys, compact separators, UTF-8.
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def credential_payload(c: Credential) -> dict:
    return {
        "credential_id": c.credential_id,
        "student_name": c.student_name,
        "student_identifier": c.student_identifier,
        "institution": c.institution,
        "qualification": c.qualification,
        "department": c.department,
        "graduation_year": c.graduation_year,
        "issue_date": c.issue_date,
    }

def make_hash(data: dict) -> str:
    return hashlib.sha256(canonical_payload(data)).hexdigest()

def require_issuer(x_demo_issuer_token: str | None):
    if x_demo_issuer_token != DEMO_ISSUER_TOKEN:
        raise HTTPException(status_code=401, detail="Issuer authorization required. Configure the demo token in frontend/.env or backend/.env.")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "BlockCred API"}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    rows = db.query(Credential).order_by(desc(Credential.id)).limit(6).all()
    return {
        "total_credentials": db.query(Credential).count(),
        "successful_verifications": db.query(VerificationEvent).filter(VerificationEvent.status == "VERIFIED").count(),
        "revoked_credentials": db.query(Credential).filter(Credential.revoked == True).count(),
        "recent": [{"credential_id": c.credential_id, "student_name": c.student_name, "qualification": c.qualification, "institution": c.institution, "blockchain_confirmed": c.blockchain_confirmed, "revoked": c.revoked} for c in rows]
    }

@app.post("/api/credentials", status_code=201)
def issue_credential(body: CredentialCreate, db: Session = Depends(get_db), x_demo_issuer_token: str | None = Header(default=None)):
    require_issuer(x_demo_issuer_token)
    credential_id = "BC-" + uuid.uuid4().hex[:12].upper()
    data = body.model_dump()
    data["issue_date"] = body.issue_date.isoformat()
    payload = {"credential_id": credential_id, **data}
    digest = make_hash(payload)
    row = Credential(credential_id=credential_id, **data, credential_hash="0x" + digest)
    db.add(row)
    db.commit()
    db.refresh(row)
    try:
        tx_hash = chain.issue_hash(digest)
        row.transaction_hash = tx_hash
        row.blockchain_confirmed = True
        db.commit()
    except Exception as exc:
        # Keep the record but do not represent it as blockchain-verified.
        row.transaction_hash = None
        row.blockchain_confirmed = False
        db.commit()
        raise HTTPException(status_code=503, detail=f"Credential saved as PENDING, but blockchain issuance failed: {exc}. Configure and start the local chain, then issue a new credential.")
    return {**serialize(row), "verification_url": f"{FRONTEND_URL}/verify/{row.credential_id}"}

def serialize(c: Credential):
    return {**credential_payload(c), "credential_hash": c.credential_hash, "transaction_hash": c.transaction_hash, "blockchain_confirmed": c.blockchain_confirmed, "revoked": c.revoked}

@app.get("/api/credentials")
def list_credentials(q: str = "", db: Session = Depends(get_db)):
    query = db.query(Credential)
    if q:
        term = f"%{q}%"
        query = query.filter((Credential.credential_id.like(term)) | (Credential.student_name.like(term)) | (Credential.institution.like(term)))
    return [serialize(c) for c in query.order_by(desc(Credential.id)).all()]

@app.get("/api/credentials/{credential_id}")
def get_credential(credential_id: str, db: Session = Depends(get_db)):
    row = db.query(Credential).filter_by(credential_id=credential_id).first()
    if not row:
        raise HTTPException(404, "Credential not found")
    return serialize(row)

@app.get("/api/verify/{credential_id}")
def verify_credential(credential_id: str, db: Session = Depends(get_db)):
    row = db.query(Credential).filter_by(credential_id=credential_id).first()
    if not row:
        db.add(VerificationEvent(credential_id=credential_id, status="INVALID", details="No matching database record"))
        db.commit()
        return {"status": "INVALID", "message": "No credential with this ID was found.", "credential": None}
    expected = "0x" + make_hash(credential_payload(row))
    if expected != row.credential_hash:
        status, message = "INVALID", "Credential data hash does not match the stored hash."
    elif not row.blockchain_confirmed:
        status, message = "PENDING", "Credential exists in the database but blockchain issuance has not been confirmed."
    else:
        try:
            exists, revoked_on_chain = chain.check_hash(row.credential_hash)
            if not exists:
                status, message = "INVALID", "Credential hash was not found on the blockchain."
            elif revoked_on_chain or row.revoked:
                status, message = "REVOKED", "This credential has been revoked."
            else:
                status, message = "VERIFIED", "Credential record matches and its hash exists on-chain."
        except Exception as exc:
            status, message = "PENDING", f"Blockchain could not be checked: {exc}"
    row.last_verification_status = status
    db.add(VerificationEvent(credential_id=credential_id, status=status, details=message))
    db.commit()
    return {"status": status, "message": message, "credential": serialize(row) if status in ("VERIFIED", "REVOKED", "PENDING") else None}

@app.post("/api/credentials/{credential_id}/revoke")
def revoke_credential(credential_id: str, db: Session = Depends(get_db), x_demo_issuer_token: str | None = Header(default=None)):
    require_issuer(x_demo_issuer_token)
    row = db.query(Credential).filter_by(credential_id=credential_id).first()
    if not row:
        raise HTTPException(404, "Credential not found")
    if row.revoked:
        raise HTTPException(409, "Credential is already revoked")
    try:
        tx_hash = chain.revoke_hash(row.credential_hash)
    except Exception as exc:
        raise HTTPException(503, detail=f"Blockchain revocation failed; database status unchanged: {exc}")
    row.revoked = True
    row.transaction_hash = tx_hash
    db.commit()
    return {"status": "REVOKED", "transaction_hash": tx_hash, "credential_id": credential_id}

@app.get("/api/credentials/{credential_id}/qr")
def credential_qr(credential_id: str, db: Session = Depends(get_db)):
    row = db.query(Credential).filter_by(credential_id=credential_id).first()
    if not row:
        raise HTTPException(404, "Credential not found")
    url = f"{FRONTEND_URL}/verify/{row.credential_id}"
    image = qrcode.make(url)
    stream = io.BytesIO()
    image.save(stream, format="PNG")
    stream.seek(0)
    return StreamingResponse(stream, media_type="image/png")
