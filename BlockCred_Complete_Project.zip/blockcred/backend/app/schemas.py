from pydantic import BaseModel, Field, ConfigDict
from datetime import date
from typing import Literal

class CredentialCreate(BaseModel):
    student_name: str = Field(min_length=2, max_length=160)
    student_identifier: str = Field(min_length=1, max_length=100)
    institution: str = Field(min_length=2, max_length=200)
    qualification: str = Field(min_length=2, max_length=200)
    department: str = Field(min_length=2, max_length=200)
    graduation_year: int = Field(ge=1950, le=2100)
    issue_date: date

class CredentialOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    credential_id: str
    student_name: str
    student_identifier: str
    institution: str
    qualification: str
    department: str
    graduation_year: int
    issue_date: str
    credential_hash: str
    transaction_hash: str | None
    blockchain_confirmed: bool
    revoked: bool

class VerificationOut(BaseModel):
    status: Literal["VERIFIED", "REVOKED", "INVALID", "PENDING"]
    message: str
    credential: dict | None = None
