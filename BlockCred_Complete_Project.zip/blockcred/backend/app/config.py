import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./blockcred.db")
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173")
RPC_URL = os.getenv("RPC_URL", "http://127.0.0.1:8545")
CONTRACT_ADDRESS = os.getenv("CONTRACT_ADDRESS", "")
ISSUER_PRIVATE_KEY = os.getenv("ISSUER_PRIVATE_KEY", "")
CHAIN_ID = int(os.getenv("CHAIN_ID", "31337"))
DEMO_ISSUER_TOKEN = os.getenv("DEMO_ISSUER_TOKEN", "change-this-demo-token")
