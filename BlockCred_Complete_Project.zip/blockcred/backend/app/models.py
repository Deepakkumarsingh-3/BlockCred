from datetime import datetime, timezone
from sqlalchemy import String, Integer, Boolean, DateTime, Text
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

def utcnow():
    return datetime.now(timezone.utc)

class Credential(Base):
    __tablename__ = "credentials"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    credential_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    student_name: Mapped[str] = mapped_column(String(160))
    student_identifier: Mapped[str] = mapped_column(String(100))
    institution: Mapped[str] = mapped_column(String(200))
    qualification: Mapped[str] = mapped_column(String(200))
    department: Mapped[str] = mapped_column(String(200))
    graduation_year: Mapped[int] = mapped_column(Integer)
    issue_date: Mapped[str] = mapped_column(String(20))
    credential_hash: Mapped[str] = mapped_column(String(66), index=True)
    transaction_hash: Mapped[str | None] = mapped_column(String(80), nullable=True)
    blockchain_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_verification_status: Mapped[str | None] = mapped_column(String(30), nullable=True)

class VerificationEvent(Base):
    __tablename__ = "verification_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    credential_id: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30))
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
